package yourname.cardshop.rent;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import yourname.cardshop.CardShopPlugin;
import yourname.cardshop.card.CardManager;

public class RentManager {
    public static final int OK = 0;
    public static final int NOT_OWNER = 1;
    public static final int NOT_TENANT = 2;

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final CardShopPlugin plugin;
    private final CardManager cardManager;
    private final File file;
    private final Map<String, RentProperty> properties = new HashMap<>();
    // その日すでに処理したプレイヤー(同じ日の再ログインでは何もしない)
    private final Map<UUID, String> checkedDay = new HashMap<>();
    private boolean savePending = false;
    private final Object writeLock = new Object();

    public RentManager(CardShopPlugin plugin, CardManager cardManager) {
        this.plugin = plugin;
        this.cardManager = cardManager;
        this.file = new File(plugin.getDataFolder(), "rent.yml");
        load();
    }

    public CardShopPlugin getPlugin() {
        return plugin;
    }

    public RentProperty registerOwner(String id, UUID owner) {
        RentProperty p = properties.get(id);
        if (p == null) {
            p = new RentProperty(id, owner, 0.0);
            properties.put(id, p);
        } else {
            p.setOwnerUuid(owner);
        }
        checkedDay.remove(owner);
        save();
        return p;
    }

    public boolean setPrice(String id, UUID actor, double price) {
        RentProperty p = properties.get(id);
        if (p == null || !actor.equals(p.getOwnerUuid())) return false;
        p.setPrice(CardManager.round2(price));
        save();
        return true;
    }

    public int setTenantPrice(String id, UUID actor, UUID tenant, double price) {
        RentProperty p = properties.get(id);
        if (p == null || !actor.equals(p.getOwnerUuid())) return NOT_OWNER;
        if (!p.isTenant(tenant)) return NOT_TENANT;
        p.setTenantPrice(tenant, CardManager.round2(price));
        save();
        return OK;
    }

    public int clearTenantPrice(String id, UUID actor, UUID tenant) {
        RentProperty p = properties.get(id);
        if (p == null || !actor.equals(p.getOwnerUuid())) return NOT_OWNER;
        if (!p.isTenant(tenant)) return NOT_TENANT;
        p.clearTenantPrice(tenant);
        save();
        return OK;
    }

    // 管理者用。オーナー判定はしない
    public boolean setVirtualIncome(String id, double amount) {
        RentProperty p = properties.get(id);
        if (p == null) return false;
        p.setVirtualIncome(CardManager.round2(amount));
        if (p.getOwnerUuid() != null) checkedDay.remove(p.getOwnerUuid());
        save();
        return true;
    }

    public boolean addTenant(String id, UUID actor, UUID tenant) {
        RentProperty p = properties.get(id);
        if (p == null || !actor.equals(p.getOwnerUuid())) return false;
        p.addTenant(tenant);
        checkedDay.remove(tenant);
        save();
        return true;
    }

    public boolean removeTenant(String id, UUID actor, UUID tenant) {
        RentProperty p = properties.get(id);
        if (p == null || !actor.equals(p.getOwnerUuid())) return false;
        p.removeTenant(tenant);
        save();
        return true;
    }

    public RentProperty get(String id) {
        return properties.get(id);
    }

    public Map<String, RentProperty> getAll() {
        return properties;
    }

    // ログインした日の最初の1回だけ、家賃の引き落としと仮想収益の付与をする
    public void chargeOnLogin(Player player) {
        UUID uuid = player.getUniqueId();
        String today = LocalDate.now().toString();
        if (today.equals(checkedDay.get(uuid))) return;
        checkedDay.put(uuid, today);

        String now = null;
        boolean changed = false;
        double incomeTotal = 0;
        double blockedTotal = 0;
        StringBuilder paidIds = new StringBuilder();
        StringBuilder blockedIds = new StringBuilder();

        for (RentProperty p : properties.values()) {
            // 家賃
            if (p.isTenant(uuid) && !today.equals(p.getLastChargedDate(uuid))) {
                double price = p.getPriceFor(uuid);
                if (price > 0) {
                    if (now == null) now = LocalDateTime.now().format(TIME_FORMAT);
                    boolean ok = cardManager.removeBalance(uuid, price);
                    p.addHistory(new RentProperty.PaymentRecord(now, uuid, price, ok));
                    if (ok) {
                        cardManager.addBalance(p.getOwnerUuid(), price);
                        player.sendMessage("§7家賃 " + CardManager.formatMoney(price) + "円 が引き落とされました(" + p.getId() + ")。");
                    } else {
                        player.sendMessage("§c家賃(" + p.getId() + ")の残高が不足しています。");
                    }
                    p.setLastChargedDate(uuid, today);
                    changed = true;
                }
            }
            // 仮想収益
            if (uuid.equals(p.getOwnerUuid()) && p.getVirtualIncome() > 0 && !today.equals(p.getLastIncomeDate())) {
                double income = p.getVirtualIncome();
                if (cardManager.addBalance(uuid, income)) {
                    incomeTotal += income;
                    if (paidIds.length() > 0) paidIds.append(", ");
                    paidIds.append(p.getId());
                } else {
                    blockedTotal += income;
                    if (blockedIds.length() > 0) blockedIds.append(", ");
                    blockedIds.append(p.getId());
                }
                // 上限で入らなかった場合もその日の分は済みにする
                p.setLastIncomeDate(today);
                changed = true;
            }
        }

        if (incomeTotal > 0) {
            player.sendMessage("§6[物件収益] §f" + paidIds + " §7の仮想収益 合計 §a" + CardManager.formatMoney(incomeTotal) + "円 §7が振り込まれました。");
            plugin.getLogger().info("[物件収益] " + player.getName() + " ← " + paidIds + " 合計=" + CardManager.formatMoney(incomeTotal) + "円");
        }
        if (blockedTotal > 0) {
            player.sendMessage("§6[物件収益] §f" + blockedIds + " §7の仮想収益(合計 " + CardManager.formatMoney(blockedTotal) + "円)が発生しましたが、残高上限のため振り込めませんでした。");
        }
        if (changed) save();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String id : y.getKeys(false)) {
            try {
                UUID owner = UUID.fromString(y.getString(id + ".owner"));
                RentProperty p = new RentProperty(id, owner, y.getDouble(id + ".price"));
                p.setVirtualIncome(y.getDouble(id + ".income"));
                p.setLastIncomeDate(y.getString(id + ".last-income"));
                for (String t : y.getStringList(id + ".tenants")) {
                    p.addTenant(UUID.fromString(t));
                }
                if (y.isConfigurationSection(id + ".tenant-prices")) {
                    ConfigurationSection sec = y.getConfigurationSection(id + ".tenant-prices");
                    for (String k : sec.getKeys(false)) {
                        UUID t = UUID.fromString(k);
                        if (p.isTenant(t)) p.setTenantPrice(t, y.getDouble(id + ".tenant-prices." + k));
                    }
                }
                if (y.isConfigurationSection(id + ".last-charged")) {
                    ConfigurationSection sec = y.getConfigurationSection(id + ".last-charged");
                    for (String k : sec.getKeys(false)) {
                        p.setLastChargedDate(UUID.fromString(k), y.getString(id + ".last-charged." + k));
                    }
                }
                for (String line : y.getStringList(id + ".history")) {
                    String[] a = line.split("\\|");
                    if (a.length < 4) continue;
                    p.getHistory().add(new RentProperty.PaymentRecord(
                            a[0], UUID.fromString(a[1]), Double.parseDouble(a[2]), Boolean.parseBoolean(a[3])));
                }
                properties.put(id, p);
            } catch (Exception e) {
                plugin.getLogger().warning("rent.yml 読み込みエラー(" + id + "): " + e.getMessage());
            }
        }
    }

    // 変更は5秒ぶんまとめて、書き込みだけ非同期で行う
    public void save() {
        if (!plugin.isEnabled()) {
            writeFile(snapshot());
            return;
        }
        if (savePending) return;
        savePending = true;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            savePending = false;
            String data = snapshot();
            try {
                Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> writeFile(data));
            } catch (Throwable t) {
                writeFile(data);
            }
        }, 100L);
    }

    private String snapshot() {
        YamlConfiguration y = new YamlConfiguration();
        for (RentProperty p : properties.values()) {
            String base = p.getId() + ".";
            y.set(base + "owner", p.getOwnerUuid().toString());
            y.set(base + "price", p.getPrice());
            y.set(base + "income", p.getVirtualIncome());
            y.set(base + "last-income", p.getLastIncomeDate());
            y.set(base + "tenants", p.getTenants().stream().map(UUID::toString).toList());
            for (Map.Entry<UUID, Double> e : p.getTenantPrices().entrySet()) {
                y.set(base + "tenant-prices." + e.getKey(), e.getValue());
            }
            for (UUID t : p.getTenants()) {
                y.set(base + "last-charged." + t, p.getLastChargedDate(t));
            }
            y.set(base + "history", p.getHistory().stream()
                    .map(r -> r.dateTime + "|" + r.tenantUuid + "|" + r.amount + "|" + r.success).toList());
        }
        return y.saveToString();
    }

    private void writeFile(String data) {
        synchronized (writeLock) {
            try {
                if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
                Path tmp = new File(file.getParentFile(), file.getName() + ".tmp").toPath();
                Files.writeString(tmp, data, StandardCharsets.UTF_8);
                Files.move(tmp, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                plugin.getLogger().warning("rent.yml の保存に失敗: " + e.getMessage());
            }
        }
    }
}
