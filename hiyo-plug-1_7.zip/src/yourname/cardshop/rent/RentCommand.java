package yourname.cardshop.rent;

import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import yourname.cardshop.card.CardManager;

public class RentCommand implements CommandExecutor, TabCompleter {
    private static final String MSG_NOT_OWNER = "§cその物件のオーナーではありません。";
    private static final String MSG_NO_PROPERTY = "§cその物件は存在しません。";
    private static final String MSG_PLAYER_ONLY = "§cプレイヤーのみ実行できます。";
    private static final String MSG_NOT_TENANT = "§cそのプレイヤーはこの物件のテナントではありません。先に /rent addtenant で追加してください。";
    private static final String MSG_BAD_AMOUNT = "§c金額は0以上の数値で指定してください。";

    private final RentManager rentManager;

    public RentCommand(RentManager rentManager) {
        this.rentManager = rentManager;
        // TabSetup より後に補完を差し替えるため、1tick遅らせる
        try {
            var plugin = rentManager.getPlugin();
            Bukkit.getScheduler().runTask(plugin, () -> {
                PluginCommand c = plugin.getCommand("rent");
                if (c != null) c.setTabCompleter(this);
            });
        } catch (Throwable ignored) {
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§c使い方: /rent <registerowner|setprice|setincome|addtenant|removetenant|info|history> ...");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "registerowner" -> {
                if (!sender.hasPermission("cardshop.admin")) {
                    sender.sendMessage("§c権限がありません。");
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage("§c使い方: /rent registerowner <物件ID> <オーナー>");
                    return true;
                }
                var target = Bukkit.getOfflinePlayer(args[2]);
                rentManager.registerOwner(args[1], target.getUniqueId());
                sender.sendMessage("§a物件 " + args[1] + " のオーナーを " + args[2] + " に設定しました。");
            }
            case "setprice" -> handleSetPrice(sender, args);
            case "setincome" -> handleSetIncome(sender, args);
            case "addtenant" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(MSG_PLAYER_ONLY);
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage("§c使い方: /rent addtenant <物件ID> <テナント>");
                    return true;
                }
                var target = Bukkit.getOfflinePlayer(args[2]);
                boolean ok = rentManager.addTenant(args[1], player.getUniqueId(), target.getUniqueId());
                player.sendMessage(ok ? "§a" + args[2] + " をテナントに追加しました。" : MSG_NOT_OWNER);
            }
            case "removetenant" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(MSG_PLAYER_ONLY);
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage("§c使い方: /rent removetenant <物件ID> <テナント>");
                    return true;
                }
                var target = Bukkit.getOfflinePlayer(args[2]);
                boolean ok = rentManager.removeTenant(args[1], player.getUniqueId(), target.getUniqueId());
                player.sendMessage(ok ? "§a" + args[2] + " をテナントから外しました。" : MSG_NOT_OWNER);
            }
            case "info" -> handleInfo(sender, args);
            case "history" -> handleHistory(sender, args);
            default -> sender.sendMessage("§c不明なサブコマンドです。");
        }
        return true;
    }

    private void handleSetPrice(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(MSG_PLAYER_ONLY);
            return;
        }
        if (args.length < 3) {
            player.sendMessage("§c使い方: /rent setprice <物件ID> <金額> [プレイヤー]");
            player.sendMessage("§7  プレイヤーを付けるとそのテナントだけ個別の家賃になります。解除: /rent setprice <物件ID> reset <プレイヤー>");
            return;
        }
        String id = args[1];
        boolean reset = args[2].equalsIgnoreCase("reset") || args[2].equalsIgnoreCase("default");

        if (args.length == 3) {
            if (reset) {
                player.sendMessage("§c使い方: /rent setprice <物件ID> reset <プレイヤー>");
                return;
            }
            Double amount = parseAmount(args[2]);
            if (amount == null) {
                player.sendMessage(MSG_BAD_AMOUNT);
                return;
            }
            boolean ok = rentManager.setPrice(id, player.getUniqueId(), amount);
            player.sendMessage(ok ? "§a家賃を " + CardManager.formatMoney(amount) + "円 に設定しました。" : MSG_NOT_OWNER);
            return;
        }

        RentProperty p = rentManager.get(id);
        if (p == null || !player.getUniqueId().equals(p.getOwnerUuid())) {
            player.sendMessage(MSG_NOT_OWNER);
            return;
        }
        UUID tenant = findTenant(p, args[3]);
        if (tenant == null) {
            player.sendMessage(MSG_NOT_TENANT);
            return;
        }

        if (reset) {
            rentManager.clearTenantPrice(id, player.getUniqueId(), tenant);
            player.sendMessage("§a" + args[3] + " の個別家賃を解除しました(標準家賃 " + CardManager.formatMoney(p.getPrice()) + "円 が適用されます)。");
            return;
        }
        Double amount = parseAmount(args[2]);
        if (amount == null) {
            player.sendMessage(MSG_BAD_AMOUNT);
            return;
        }
        int result = rentManager.setTenantPrice(id, player.getUniqueId(), tenant, amount);
        if (result == RentManager.OK) {
            player.sendMessage("§a" + args[3] + " の家賃を " + CardManager.formatMoney(amount) + "円 に設定しました(個別設定)。");
        } else if (result == RentManager.NOT_TENANT) {
            player.sendMessage(MSG_NOT_TENANT);
        } else {
            player.sendMessage(MSG_NOT_OWNER);
        }
    }

    private void handleSetIncome(CommandSender sender, String[] args) {
        if (!sender.hasPermission("cardshop.admin")) {
            sender.sendMessage("§c権限がありません。");
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("§c使い方: /rent setincome <物件ID> <金額(1日あたり・0で無効)>");
            return;
        }
        Double amount = parseAmount(args[2]);
        if (amount == null) {
            sender.sendMessage(MSG_BAD_AMOUNT);
            return;
        }
        if (rentManager.setVirtualIncome(args[1], amount)) {
            sender.sendMessage("§a物件 " + args[1] + " の仮想収益を 1日 " + CardManager.formatMoney(amount)
                    + "円 に設定しました(オーナーがその日最初にログインした時に付与)。");
        } else {
            sender.sendMessage(MSG_NO_PROPERTY);
        }
    }

    private void handleInfo(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§c使い方: /rent info <物件ID>");
            return;
        }
        RentProperty p = rentManager.get(args[1]);
        if (p == null) {
            sender.sendMessage(MSG_NO_PROPERTY);
            return;
        }

        // 個別家賃と仮想収益はオーナーと管理者にだけ見せる
        boolean privileged = sender.hasPermission("cardshop.admin")
                || (sender instanceof Player pl && pl.getUniqueId().equals(p.getOwnerUuid()));

        String tenants;
        if (p.getTenants().isEmpty()) {
            tenants = "未設定";
        } else {
            List<String> names = new ArrayList<>();
            for (UUID t : p.getTenants()) {
                String n = String.valueOf(Bukkit.getOfflinePlayer(t).getName());
                if (privileged && p.hasTenantPrice(t)) {
                    n += "(個別 " + CardManager.formatMoney(p.getPriceFor(t)) + "円)";
                }
                names.add(n);
            }
            tenants = String.join(", ", names);
        }
        sender.sendMessage("§6[" + p.getId() + "] オーナー: " + Bukkit.getOfflinePlayer(p.getOwnerUuid()).getName()
                + " / テナント: " + tenants + " / 家賃: " + CardManager.formatMoney(p.getPrice()) + "円(標準・1人あたり)");

        if (sender instanceof Player pl && p.isTenant(pl.getUniqueId()) && !privileged) {
            sender.sendMessage("§7あなたの家賃: " + CardManager.formatMoney(p.getPriceFor(pl.getUniqueId())) + "円");
        }
        if (privileged && p.getVirtualIncome() > 0) {
            sender.sendMessage("§7仮想収益: 1日 " + CardManager.formatMoney(p.getVirtualIncome())
                    + "円(オーナーがその日最初にログインした時に付与)");
        }
    }

    private void handleHistory(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(MSG_PLAYER_ONLY);
            return;
        }
        if (args.length < 2) {
            player.sendMessage("§c使い方: /rent history <物件ID>");
            return;
        }
        RentProperty p = rentManager.get(args[1]);
        if (p == null) {
            player.sendMessage(MSG_NO_PROPERTY);
            return;
        }
        boolean isOwner = p.getOwnerUuid().equals(player.getUniqueId());
        boolean isTenant = p.isTenant(player.getUniqueId());
        if (!isOwner && !isTenant) {
            player.sendMessage("§cこの物件のオーナーまたはテナントのみ履歴を確認できます。");
            return;
        }
        player.sendMessage("§6==== " + p.getId() + " の家賃履歴(直近) ====");
        int shown = 0;
        for (RentProperty.PaymentRecord r : p.getHistory()) {
            if (!isOwner && !r.tenantUuid.equals(player.getUniqueId())) continue;
            String name = Bukkit.getOfflinePlayer(r.tenantUuid).getName();
            String result = r.success ? "§a成功" : "§c失敗(残高不足)";
            player.sendMessage("§7" + r.dateTime + " §f" + name + " §7- " + CardManager.formatMoney(r.amount) + "円 " + result);
            shown++;
            if (shown >= 20) break;
        }
        if (shown == 0) player.sendMessage("§7まだ引き落とし履歴がありません。");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        boolean admin = sender.hasPermission("cardshop.admin");
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("setprice", "addtenant", "removetenant", "info", "history"));
            if (admin) {
                subs.add(0, "registerowner");
                subs.add("setincome");
            }
            addMatches(out, subs, args[0]);
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase();
            if ((sub.equals("registerowner") || sub.equals("setincome")) && !admin) return out;
            if (List.of("registerowner", "setprice", "setincome", "addtenant", "removetenant", "info", "history").contains(sub)) {
                addMatches(out, rentManager.getAll().keySet(), args[1]);
            }
        } else if (args.length == 3) {
            switch (args[0].toLowerCase()) {
                case "addtenant" -> addMatches(out, onlineNames(), args[2]);
                case "removetenant" -> addMatches(out, tenantNames(args[1]), args[2]);
                case "registerowner" -> {
                    if (admin) addMatches(out, onlineNames(), args[2]);
                }
                case "setprice" -> addMatches(out, List.of("reset"), args[2]);
                default -> {
                }
            }
        } else if (args.length == 4 && args[0].equalsIgnoreCase("setprice")) {
            addMatches(out, tenantNames(args[1]), args[3]);
        }
        return out;
    }

    private static Double parseAmount(String s) {
        try {
            double d = Double.parseDouble(s);
            if (Double.isNaN(d) || Double.isInfinite(d) || d < 0) return null;
            return d;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // 名前の解決はテナント一覧からだけ行う(未知の名前でMojang問い合わせが走らないように)
    private static UUID findTenant(RentProperty p, String name) {
        for (UUID t : p.getTenants()) {
            String n = Bukkit.getOfflinePlayer(t).getName();
            if (n != null && n.equalsIgnoreCase(name)) return t;
        }
        return null;
    }

    private List<String> tenantNames(String id) {
        List<String> names = new ArrayList<>();
        RentProperty p = rentManager.get(id);
        if (p == null) return names;
        for (UUID t : p.getTenants()) {
            String n = Bukkit.getOfflinePlayer(t).getName();
            if (n != null) names.add(n);
        }
        return names;
    }

    private static List<String> onlineNames() {
        List<String> names = new ArrayList<>();
        for (Player pl : Bukkit.getOnlinePlayers()) names.add(pl.getName());
        return names;
    }

    private static void addMatches(List<String> out, Collection<String> candidates, String prefix) {
        String lower = prefix.toLowerCase();
        for (String c : candidates) {
            if (c.toLowerCase().startsWith(lower)) out.add(c);
        }
        Collections.sort(out);
    }
}
